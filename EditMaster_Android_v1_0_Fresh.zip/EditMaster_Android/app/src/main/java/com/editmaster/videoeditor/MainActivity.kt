package com.editmaster.videoeditor

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

private val Ink = Color(0xFF111318)
private val Panel = Color(0xFF1D222B)
private val Accent = Color(0xFF35D0B0)
private val Muted = Color(0xFF9AA3B2)

private data class VideoClip(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val startMs: Long = 0L,
    val endMs: Long = durationMs
) {
    val lengthMs: Long get() = (endMs - startMs).coerceAtLeast(0L)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Ink, surface = Panel,
                onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
            )) { EditorScreen() }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun EditorScreen() {
    val context = LocalContext.current
    val clips = remember { mutableStateListOf<VideoClip>() }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var isExporting by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf("Import one or more videos to begin") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    val selected = clips.getOrNull(selectedIndex)
    val totalDuration = clips.sumOf { it.lengthMs }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.coerceAtLeast(1L) ?: 1L
                val name = uri.lastPathSegment?.substringAfterLast('/')?.take(24) ?: "Video ${clips.size + 1}"
                clips.add(VideoClip(System.nanoTime(), uri, name, duration))
                retriever.release()
            } catch (_: Exception) {
                Toast.makeText(context, "Could not read one selected video", Toast.LENGTH_SHORT).show()
            }
        }
        if (clips.isNotEmpty()) {
            selectedIndex = (clips.size - uris.size).coerceAtLeast(0)
            exportStatus = "${clips.size} clip(s) in timeline"
        }
    }

    DisposableEffect(Unit) {
        val exo = ExoPlayer.Builder(context).build()
        player = exo
        onDispose { exo.release(); player = null }
    }

    LaunchedEffect(clips.map { it.id to it.uri }, selectedIndex) {
        val exo = player ?: return@LaunchedEffect
        if (clips.isNotEmpty()) {
            val mediaItems = clips.map { MediaItem.fromUri(it.uri) }
            exo.setMediaItems(mediaItems, selectedIndex.coerceIn(0, clips.lastIndex), 0L)
            exo.prepare()
            exo.playWhenReady = false
        } else {
            exo.clearMediaItems()
        }
    }

    fun splitSelected() {
        val clip = clips.getOrNull(selectedIndex) ?: return
        if (clip.lengthMs < 1000L) {
            Toast.makeText(context, "Clip must be at least 1 second to split", Toast.LENGTH_SHORT).show()
            return
        }
        val middle = clip.startMs + clip.lengthMs / 2
        val first = clip.copy(id = System.nanoTime(), endMs = middle)
        val second = clip.copy(id = System.nanoTime() + 1, startMs = middle)
        clips.removeAt(selectedIndex)
        clips.add(selectedIndex, second)
        clips.add(selectedIndex, first)
        selectedIndex += 1
        exportStatus = "Clip split into two parts"
    }

    fun moveSelected(delta: Int) {
        val target = selectedIndex + delta
        if (target !in clips.indices) return
        val item = clips.removeAt(selectedIndex)
        clips.add(target, item)
        selectedIndex = target
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Ink)
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("EDIT MASTER", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("Multi-Track Studio", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Button(onClick = { picker.launch(arrayOf("video/*")) },
                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Icon(Icons.Default.Add, null, tint = Ink)
                Spacer(Modifier.width(5.dp))
                Text("Import", color = Ink)
            }
        }

        Surface(color = Color.Black, shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            if (player != null && clips.isNotEmpty()) {
                val activePlayer = player
                AndroidView(factory = { ctx -> PlayerView(ctx).apply {
                    this.player = activePlayer
                    useController = true
                } }, update = { view -> view.player = activePlayer }, modifier = Modifier.fillMaxSize())
            } else {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(42.dp))
                    Text("Import multiple videos to preview", color = Muted)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text("TIMELINE", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("${clips.size} clips  •  ${formatTime(totalDuration)}", color = Muted, fontSize = 12.sp)
        }
        if (clips.isEmpty()) {
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Text("No clips yet. Tap Import and select multiple videos.", color = Muted,
                    modifier = Modifier.padding(18.dp))
            }
        } else {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                clips.forEachIndexed { index, clip ->
                    Surface(color = if (index == selectedIndex) Color(0xFF31505A) else Panel,
                        shape = RoundedCornerShape(10.dp), modifier = Modifier.width(150.dp)
                            .clickable { selectedIndex = index }) {
                        Column(Modifier.padding(10.dp)) {
                            Text("VIDEO ${index + 1}", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(clip.name, color = Color.White, maxLines = 1, fontSize = 12.sp)
                            Text(formatTime(clip.lengthMs), color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            selected?.let { clip ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("SELECTED CLIP  •  ${selectedIndex + 1}", color = Accent, fontWeight = FontWeight.Bold)
                        Text("Trim start  •  ${formatTime(clip.startMs)}", color = Muted, fontSize = 12.sp)
                        Slider(value = clip.startMs.toFloat(), onValueChange = { value ->
                            clips[selectedIndex] = clip.copy(startMs = value.toLong().coerceIn(0L, clip.endMs - 500L))
                        }, valueRange = 0f..clip.durationMs.toFloat().coerceAtLeast(1f))
                        val latest = clips[selectedIndex]
                        Text("Trim end  •  ${formatTime(latest.endMs)}", color = Muted, fontSize = 12.sp)
                        Slider(value = latest.endMs.toFloat(), onValueChange = { value ->
                            clips[selectedIndex] = latest.copy(endMs = value.toLong().coerceIn(latest.startMs + 500L, latest.durationMs))
                        }, valueRange = 0f..latest.durationMs.toFloat().coerceAtLeast(1f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { splitSelected() }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.ContentCut, null); Text(" Split")
                            }
                            OutlinedButton(onClick = { if (clips.size > 1) { clips.removeAt(selectedIndex); selectedIndex = selectedIndex.coerceAtMost(clips.lastIndex) } else { clips.clear(); selectedIndex = 0 } }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Delete, null); Text(" Delete")
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { moveSelected(-1) }, modifier = Modifier.weight(1f), enabled = selectedIndex > 0) {
                                Icon(Icons.Default.ArrowUpward, null); Text(" Move up")
                            }
                            OutlinedButton(onClick = { moveSelected(1) }, modifier = Modifier.weight(1f), enabled = selectedIndex < clips.lastIndex) {
                                Icon(Icons.Default.ArrowDownward, null); Text(" Move down")
                            }
                        }
                    }
                }
            }
        }

        Button(onClick = {
            if (clips.isEmpty() || isExporting) return@Button
            val invalid = clips.any { it.lengthMs < 500L }
            if (invalid) {
                Toast.makeText(context, "Each clip must have at least 0.5 seconds", Toast.LENGTH_LONG).show()
                return@Button
            }
            val editedItems = clips.map { clip ->
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.startMs).setEndPositionMs(clip.endMs).build()
                EditedMediaItem.Builder(MediaItem.Builder().setUri(clip.uri)
                    .setClippingConfiguration(clipping).build()).build()
            }
            val sequence = androidx.media3.transformer.EditedMediaItemSequence.Builder(editedItems).build()
            val composition = Composition.Builder(sequence).build()
            val outDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: context.filesDir
            val outFile = File(outDir, "EditMaster_${System.currentTimeMillis()}.mp4")
            isExporting = true
            exportStatus = "Exporting ${clips.size} clips…"
            val transformer = Transformer.Builder(context).addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    isExporting = false
                    exportStatus = "Export complete: ${outFile.name}"
                    Toast.makeText(context, "Export complete. Saved in app Movies folder.", Toast.LENGTH_LONG).show()
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    isExporting = false
                    exportStatus = "Export failed: ${exportException.message ?: "Unknown error"}"
                    Toast.makeText(context, exportStatus, Toast.LENGTH_LONG).show()
                }
            }).build()
            transformer.start(composition, outFile.absolutePath)
        }, enabled = clips.isNotEmpty() && !isExporting,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
            if (isExporting) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            else Icon(Icons.Default.FileDownload, null, tint = Ink)
            Spacer(Modifier.width(8.dp))
            Text(if (isExporting) "Exporting…" else "Export All Clips as MP4", color = Ink, fontWeight = FontWeight.Bold)
        }
        Text(exportStatus, color = Muted, fontSize = 12.sp)
        Text("Edit Master • Multi-clip foundation build", color = Muted, fontSize = 10.sp)
    }
}

private fun formatTime(ms: Long): String {
    val total = ms.coerceAtLeast(0L) / 1000L
    return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}
