package com.editmaster.videoeditor

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.Locale

private val Ink = Color(0xFF111318)
private val Panel = Color(0xFF1D222B)
private val Accent = Color(0xFF35D0B0)
private val Muted = Color(0xFF9AA3B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary = Accent, background = Ink, surface = Panel,
            onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
        )) { EditorScreen() } }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun EditorScreen() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableFloatStateOf(0f) }
    var endMs by remember { mutableFloatStateOf(0f) }
    var isExporting by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf("Ready to edit") }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            videoUri = uri
            player?.release()
            player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = false
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            durationMs = this@apply.duration.coerceAtLeast(0L)
                            endMs = durationMs.toFloat()
                        }
                    }
                })
            }
            exportStatus = "Video loaded"
        }
    }

    DisposableEffect(Unit) {
        onDispose { player?.release(); player = null }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Ink)
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("EDIT MASTER", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Video Studio", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Button(onClick = { picker.launch(arrayOf("video/*")) },
                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Import", color = Ink)
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            if (player != null) {
                AndroidView(factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                    }
                }, update = { it.player = player }, modifier = Modifier.fillMaxSize())
            } else {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.Movie, null, tint = Muted, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Your video preview", color = Muted)
                    Text("Import a video to start", color = Muted, fontSize = 12.sp)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text("TIMELINE", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(formatTime(durationMs), color = Muted, fontSize = 12.sp)
        }
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (videoUri == null) "No clip selected" else "VIDEO 1  •  ${formatTime(durationMs)}",
                    color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.fillMaxWidth().height(54.dp).background(Color(0xFF344D5A), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center) {
                    Text(if (videoUri == null) "Import a video" else "Selected video clip",
                        color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                Text("Trim start  •  ${formatTime(startMs.toLong())}", color = Muted, fontSize = 12.sp)
                Slider(value = startMs, onValueChange = {
                    startMs = it.coerceIn(0f, (endMs - 500f).coerceAtLeast(0f))
                }, valueRange = 0f..(durationMs.toFloat().coerceAtLeast(1f)),
                    enabled = videoUri != null && durationMs > 500)
                Text("Trim end  •  ${formatTime(endMs.toLong())}", color = Muted, fontSize = 12.sp)
                Slider(value = endMs, onValueChange = {
                    endMs = it.coerceIn(startMs + 500f, durationMs.toFloat())
                }, valueRange = 0f..(durationMs.toFloat().coerceAtLeast(1f)),
                    enabled = videoUri != null && durationMs > 500)
                Text("The selected range will be exported as a new MP4.", color = Muted, fontSize = 11.sp)
            }
        }

        Text("EDIT TOOLS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToolTile("Trim", Icons.Default.ContentCut, Modifier.weight(1f))
            ToolTile("Audio", Icons.Default.MusicNote, Modifier.weight(1f))
            ToolTile("Text", Icons.Default.TextFields, Modifier.weight(1f))
            ToolTile("Filters", Icons.Default.Tune, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToolTile("Speed", Icons.Default.Speed, Modifier.weight(1f))
            ToolTile("Crop", Icons.Default.Crop, Modifier.weight(1f))
            ToolTile("Overlay", Icons.Default.Layers, Modifier.weight(1f))
            ToolTile("More", Icons.Default.MoreHoriz, Modifier.weight(1f))
        }

        Button(
            onClick = {
                val uri = videoUri ?: return@Button
                if (endMs <= startMs || endMs - startMs < 500f) {
                    Toast.makeText(context, "Select a valid trim range", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                val outDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
                    ?: context.filesDir
                val outFile = File(outDir, "EditMaster_${System.currentTimeMillis()}.mp4")
                isExporting = true
                exportStatus = "Exporting video…"
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs.toLong())
                    .setEndPositionMs(endMs.toLong())
                    .build()
                val item = EditedMediaItem.Builder(
                    MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
                ).build()
                val transformer = Transformer.Builder(context)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            isExporting = false
                            exportStatus = "Export complete: ${outFile.name}"
                            Toast.makeText(context, "Saved in app Movies folder", Toast.LENGTH_LONG).show()
                        }
                        override fun onError(composition: Composition, exportResult: ExportResult,
                                             exportException: ExportException) {
                            isExporting = false
                            exportStatus = "Export failed: ${exportException.message ?: "Unknown error"}"
                            Toast.makeText(context, exportStatus, Toast.LENGTH_LONG).show()
                        }
                    }).build()
                transformer.start(item, outFile.absolutePath)
            },
            enabled = videoUri != null && !isExporting,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, disabledContainerColor = Color.DarkGray)
        ) {
            if (isExporting) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            else Icon(Icons.Default.FileDownload, null, tint = Ink)
            Spacer(Modifier.width(8.dp))
            Text(if (isExporting) "Exporting…" else "Export MP4", color = Ink, fontWeight = FontWeight.Bold)
        }
        Text(exportStatus, color = Muted, fontSize = 12.sp)
        Text("Edit Master • Version 1.0 • More editing tools are planned for the next build.",
            color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ToolTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(12.dp), modifier = modifier.height(76.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Accent)
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 11.sp, color = Color.White)
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L)
    return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}
