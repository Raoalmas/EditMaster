# Edit Master – Multi-clip foundation

This source update replaces the original single-`videoUri` editor with a multi-clip editing foundation.

## Implemented in this build
- Select multiple videos in one Android document-picker action.
- Keep each imported video as a separate timeline clip.
- Select a clip and adjust its trim-in / trim-out range.
- Split the selected clip into two adjacent timeline segments.
- Delete a selected clip.
- Move clips earlier or later in the sequence.
- Preview the imported clips as an ExoPlayer playlist.
- Export the trimmed clips in timeline order as one MP4 using Media3 Transformer.

## Not implemented yet
Audio/music lanes, text/subtitle lanes, picture-in-picture overlays, filters, speed controls, crop controls, waveform display, and drag-to-reorder are the next development phase. They are deliberately not presented as working controls in this foundation build.

## Build
Open the `EditMaster_Android` folder in Android Studio with JDK 17. Allow Gradle sync, then build the `app` debug variant. The project uses AndroidX Media3 1.5.1 and Compose.

Exported videos are currently written to the app-specific Movies directory. They are not automatically copied to the public Gallery.
