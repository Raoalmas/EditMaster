# Edit Master — Native Android starter

This is the first native Android build of Edit Master.

## Included in this first build
- Native Kotlin + Jetpack Compose UI
- Android system video picker
- ExoPlayer video preview
- Start/end trim range controls
- Media3 Transformer MP4 export of the selected range
- Dark editing-studio interface

## Important
The Audio, Text, Filters, Speed, Crop and Overlay tiles are visual placeholders in this first build. They are not implemented yet. Multi-track editing, project persistence, waveform editing, transitions, captions and advanced effects are planned for later versions.

## Build
Open this folder in Android Studio or a compatible Android Gradle build environment.
Use JDK 17 and Android SDK 35. Let Gradle sync, then build the `app` debug APK.

The app exports to its app-specific Movies directory:
`Android/data/com.editmaster.videoeditor/files/Movies/`

No broad storage permission is required because the app uses Android's document picker.

## Package
`com.editmaster.videoeditor`

## Version
1.0 starter
